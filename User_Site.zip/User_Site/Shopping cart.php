<?php
include("dataconnection.php");
if(isset($_POST['update_update_btn'])){
   $update_value = $_POST['update_quantity'];
   $update_id = $_POST['update_quantity_id'];
   $update_quantity_query = mysqli_query($connect, "UPDATE `cart` SET product_quantity = '$update_value' WHERE cart_id = '$update_id'");
   if($update_quantity_query){
      header('location:Shopping cart.php');
   };
};
if(isset($_GET['remove'])){
   $remove_id = $_GET['remove'];
   mysqli_query($connect, "DELETE FROM `cart` WHERE cart_id = '$remove_id'");
   header('location:Shopping cart.php');
};

?>
<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <title>Electronic Gadget Store</title>
	
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
	
	<link rel="stylesheet" type="text/css" href="assets/css/cart_CSS.css">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="assets/css/fontawesome.css">
    <link rel="stylesheet" href="assets/css/tooplate-main.css">
    <link rel="stylesheet" href="assets/css/owl.css">
    <link rel="stylesheet" href="assets/css/flex-slider.css">
	
	<!--Font style from google-->
	<link href="https://fonts.googleapis.com/css2?family=Aguafina+Script&family=Alex+Brush&family=Architects+Daughter&family=Birthstone&family=Birthstone+Bounce&family=Roboto&display=swap" rel="stylesheet">
	<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100&family=Roboto&display=swap" rel="stylesheet">
	
	

  </head>

  <body>
    
    <!-- Pre Header -->
    <div id="pre-header">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
          <span>Official Webside Electronic Gadget Store</span>
          </div>
        </div>
      </div>
    </div>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark static-top">
      <div class="container">
       <a class="navbar-brand" href="#"><p style="font-family: 'Birthstone', cursive; color:#0000cd; font-size:3.25em;">Electronic Gadgets Store</p></a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item">
              <a class="nav-link" href="index_logged_in.php">Home</a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="Product list.php">Products
               
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="About us.php">About Us</a>
            </li>
            <li class="nav-item active">
              <a class="nav-link" href="Contact us.php">Contact Us</a>
              
            </li>
			<li class="nav-item">
			  <a href="Shopping Cart.php" > <i class="fas fa-shopping-cart" title="Shopping Cart" ></i> </a>
			  <span class="sr-only">(current)</span>
			  </li>
			  
			  <li class="nav-item">
			  <div class="dropdown">
			  <button class="dropbtn">
			  <a href="#.html" > <i class="far fa-user" title="User Account"></i> </a>
			  </button>
			  <div class="dropdown-content">
			   <a class="nav-link" href="user edit.html">My Account</a> 
              <a class="nav-link" href="login_form.html">Logout</a>
				</div>
			  
			  </div>
			  </li>
          </ul>
        </div>
      </div>
    </nav>

    <!-- Page Content -->
    <!-- About Page Starts Here -->
    <div class="contact-page">
      <div class="container">
        <div class="container">
		<h1>Shopping Cart</h1>
		<?php
		$select_cart = mysqli_query($connect,"SELECT * FROM cart");
		$grand_total = 0;
		if(mysqli_num_rows($select_cart)>0)
		{
			while($fetch_cart=mysqli_fetch_assoc($select_cart)){
		?>		
		<div class="cart">
		<div class="products">
		<div class="product">
		
			<img src= "assets/images/<?php echo $fetch_cart['product_image'];?>"alt="">
		

		<div class="product-info">
		<h3 class="product-name"><?php echo $fetch_cart['product_name'];?></h3>
		<h4 class="product-price">RM<?php echo $fetch_cart['product_price'];?></h4>
		<form action="" method="post">
		<input type="hidden" name="update_quantity_id" value="<?php echo $fetch_cart ['cart_id']?>">
		<p class="product-quantity"><input type="number" name="update_quantity" min="1" 
		value=" <?php echo $fetch_cart['product_quantity'];?>">
		<input type="submit" value="update" name="update_update_btn">
		</form>
		RM<?php echo $sub_total = number_format($fetch_cart['product_price'] * $fetch_cart['product_quantity']);?>/-
		<p class="product-remove"><span class="remove">
		<a href="Shopping cart.php?remove=<?php echo $fetch_cart['cart_id']; ?>" 
		onclick="return confirm('remove item from cart?')" class="delete-btn">
		<i class="fas fa-trash"></i> remove</a></span>
	    
		</p>
		</div>
		</div>
		</div>
		</div>
		<?php
           $grand_total += $sub_total;  
            };
         };
         ?>
		<div class="cart-total">
		 
		<p>
		<td><a href="Product list.php" class="option-btn" style="margin-top: 0;">Continue Shopping</a></td>
		<span>Total Price:</span>
		<span>RM<?php echo $grand_total;?>/-</span>
		
		</p>
		<a href="Payment type.php">Proceed to Checkout</a>
		</div>
		</div>
		</div>
      </div>
	  
    <!-- About Page Ends Here -->

     <!-- Subscribe Form Starts Here -->
    <div class="subscribe-form">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-heading">
              <div class="line-dec"></div>
              <h1>Subscribe on Rapid Grocery Store now!</h1>
            </div>
          </div>
          <div class="col-md-8 offset-md-2">
            <div class="main-content">
              <p>Subscribe us now! We will notify you when our newest arrived product and we will giveaway the reward up to 45% discount ! </p>
              <div class="container">
                <form id="subscribe" action="" method="get">
                  <div class="row">
                    <div class="col-md-7">
                      <fieldset>
                        <input name="email" type="text" class="form-control" id="email" 
                        onfocus="if(this.value == 'Your Email...') { this.value = ''; }" 
                    	onBlur="if(this.value == '') { this.value = 'Your Email...';}"
                    	value="Your Email..." required="">
                      </fieldset>
                    </div>
                    <div class="col-md-5">
                      <fieldset>
                        <button type="submit" id="form-submit" class="button">Subscribe Now!</button>
                      </fieldset>
                    </div>
                  </div>
                </form>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Subscribe Form Ends Here -->


    
    <!-- Footer Starts Here -->
    <div class="footer">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
          </div>
          <div class="col-md-12">
            <div class="footer-menu">
              <ul>
                <li><a href="#">Home</a></li>
                <li><a href="#">Help</a></li>
                <li><a href="#">Privacy Policy</a></li>
                <li><a href="#">How It Works ?</a></li>
                <li><a href="#">Contact Us</a></li>
              </ul>
            </div>
          </div>
          <div class="col-md-12">
            <div class="social-icons">
              <ul>
                <li><a href="#"><i class="fa fa-facebook"></i></a></li>
                <li><a href="#"><i class="fa fa-twitter"></i></a></li>
                <li><a href="#"><i class="fa fa-linkedin"></i></a></li>
                <li><a href="#"><i class="fa fa-rss"></i></a></li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Footer Ends Here -->


    <!-- Sub Footer Starts Here -->
    <div class="sub-footer">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="copyright-text">
              <p>Copyright &copy; 2021 RAPID GROCERY STORE(MLK) SDN.BHD. 
                
          
            </div>
          </div>
        </div>
      </div>
    </div>
    <!-- Sub Footer Ends Here -->


    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>


    <!-- Additional Scripts -->
    <script src="assets/js/custom.js"></script>
    <script src="assets/js/owl.js"></script>
    <script src="assets/js/isotope.js"></script>
    <script src="assets/js/flex-slider.js"></script>


    <script language = "text/Javascript"> 
      cleared[0] = cleared[1] = cleared[2] = 0; //set a cleared flag for each field
      function clearField(t){                   //declaring the array outside of the
      if(! cleared[t.id]){                      // function makes it static and global
          cleared[t.id] = 1;  // you could use true and false, but that's more typing
          t.value='';         // with more chance of typos
          t.style.color='#fff';
          }
      }
    </script>


  </body>

</html>