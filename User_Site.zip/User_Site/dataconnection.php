<?php
$connect=mysqli_connect("localhost","root","","fyp 2022");

if($connect)
{
	echo"Connect Successfully";
}
else
{
	die("Could not connect".mysql_error());
}
?>