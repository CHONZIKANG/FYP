<!DOCTYPE html>   
<html>
<?php include("dataconnection.php");?>
<link rel="stylesheet" href="staff.css">
<?php
	$profile=mysqli_query($connect,"SELECT * FROM profile");
?>

<div class="staff">
<style>
.staff {
  text-align:left;
  border-radius:10px;
  box-shadow:0px 0px 10px #000;
  height:0 auto;
  width:880px;
  margin:0 auto;
}

</style>
  <div class="staff-header">
    <h2>Staffs</h2>
	<label>   
    <a href="profile.php" value="Add New Staff" class="add" style="float:right" >Add New Staff</a>
    <br>
	<br>
  </div>
  
  <?php
  while($row=mysqli_fetch_assoc($profile))
  {
	   
  ?>
  
  <div ol class="staff1">
	<img src="<?php echo $profile_image="image/".$row['profile_image']; ?>" width="230" height="200">
	<h2>&ensp;Name :</h2>
	<h3>&ensp;<?php echo $row["Name"]; ?></h3>
	<br>
    <h2>&ensp;Phone :</h2>
	<h3>&ensp;<?php echo $row["Phone"]; ?></h3>
	<br>
	<h2>&ensp;IC Number :</h2>
	<h3>&ensp;<?php echo $row["IC_Number"]; ?></h3>
	<br>
	<h2>&ensp;Email :</h2>
	<h3>&ensp;<?php echo $row["Email"]; ?></h3>
  </div>
	<?php
  }
	?>
	
	
  </div>

</body>
</html> 