<!DOCTYPE html> 
<?php include("dataconnection.php");?>
<html>
<?php
	
	$error="";
	$valid=1;
	$success=0;
	
	if(isset($_POST["send"]))
	{
		$name = $_POST["name"];
		$phone = $_POST["phone"];
		$ICnumber = $_POST["ICnumber"];
		$email = $_POST["email"];
		$password = $_POST["password"];
		
		$filename = $_FILES["myfile"]["name"];
		$tempname = $_FILES["myfile"]["tmp_name"];    
        $folder = "image/".$filename;
		
		if(empty($name))
		{
			$valid=0;		
		}
		else
		{
			$error="";
			$valid=1;			
		}
		
		echo $name;
		
		if(empty($phone))
		{
			$valid=0;
			
		}
		else
		{
			$error="";
			$valid=1;			
		}
		
		echo $phone;
		
		if(empty($ICnumber))
		{
			$valid=0;
			
		}
		else
		{
			$error="";
			$valid=1;			
		}
		
		echo $ICnumber;
		
		if(empty($email))
		{
			$valid=0;
			
		}
		else
		{
			$error="";
			$valid=1;			
		}
		
		echo $email;
		
		if(empty($password))
		{
			$valid=0;
			
		}
		else
		{
			$error="";
			$valid=1;			
		}
		
		echo $password;
		
		if($valid==1)
		{
			
			$success=mysqli_query($connect,"INSERT INTO profile (Name,Phone,IC_Number,Email,Password,profile_image) VALUES ('$name','$phone','$ICnumber','$email','$password','$filename')");
			
		}
		
		if (move_uploaded_file($tempname, $folder))  
		{
            $msg = "Image uploaded successfully";
        }else
		{
            $msg = "Failed to upload image";
        }
		
		if($success)
		{
		?>
		
		<script>
		
			alert("You profile have been recorded.");

		</script>
		
		<?php
		header( "refresh:0; url=profile.php" );
		}
	}
	
?>
<style>
.user-edit input[type="submit"] 
{
  height:40px;
  width:200px;
  background:black ;
  border:1px solid #f2f2f2;
  border-radius:20px;
  color: silver ;
  text-transform:uppercase;
  font-family: 'Ubuntu', sans-serif;
  cursor:pointer;
  font-size:150%;
  justify-content: center;
  align-items: center;
}

</style>
<link rel="stylesheet" href="profile.css">

<div class="profile">
  <div class="profile-header">
  <form id="Login-form"  method="POST" action="" enctype="multipart/form-data">
    <h2>PROFILE</h2>
	<br>
  </div>
  <div class="profile-form">
	<img src="username.PNG" width="160" height="160" align="center">
	<input type="file" id="myfile" name="myfile" value="">
	<hr>
  
	<div class="user-edit">
<br>
    <h3>Name:</h3>
    <input type="text" name="name" placeholder="Enter your name" required/><br>
	
	<h3>Password:</h3>
    <input type="password" name="password" placeholder="Enter your password" required/><br>
	
	<h3>Phone:</h3>
    <input type="text" name="phone" placeholder="Enter your phone number" required/><br>
	
	<h3>IC number:</h3>
    <input type="text" name="ICnumber" placeholder="Enter your IC number" required/><br>
	
	<h3>Email:</h3>
    <input type="text" name="email" placeholder="Enter your email" required/><br>


<br>    
	<label>   
	<br>
	<br>
    <input type="submit" name="send" value="Save" class="save-button" >
<br>

</div>
	
</div>
</form>
</div>
</body>
</html> 