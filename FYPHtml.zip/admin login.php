<!DOCTYPE html>
<?php include("connection.php");?>
<html>
<?php
	
	$error="";
	$valid=1;
	$success=0;
	
	if(isset($_POST["send"]))
	{
		$Name = $_POST['username'];  
		$Password = $_POST['password'];  

        $Name = stripcslashes($Name);  
        $Password = stripcslashes($Password);  
        $Name = mysqli_real_escape_string($con, $Name);  
        $Password = mysqli_real_escape_string($con, $Password);  
      
        $sql = "select *from profile where Name = '$Name' and Password = '$Password'";  
        $result = mysqli_query($con, $sql);  
        $row = mysqli_fetch_array($result, MYSQLI_ASSOC);  
        $count = mysqli_num_rows($result);  
		
		if($count == 1)
		{  
            ?>
		
		<script>
		
			alert("You are login successfully");

		</script>
		
		<?php
		header( "refresh:0; url=admin login.php" );
		
        }  
        else
		{  
            ?>
		
		<script>
		
			alert("You are login failed.Please enter again.");

		</script>
		
		<?php
		header( "refresh:0; url=admin login.php" );
        }  

	}
?>
  <head>
  <style>
  
.login-form input[type="submit"] {
  height:30px;
  width:100px;
  background:black;
  border:1px solid #f2f2f2;
  border-radius:20px;
  color: slategrey;
  text-transform:uppercase;
  font-family: 'Ubuntu', sans-serif;
  cursor:pointer;
}

</style>
	<link rel="stylesheet" href="login.css">
  </head>
  <body>
    <div class="login">
      <div class="login-header">
    <h1>Admin Login</h1>
  </div>
    <div class="login-form">
	<form id="Login-form" method="post">	  
		  
	<img src="username.PNG" width="60" height="60" align="left">
    <h3 style="color:grey;">Username:</h3>
    <input type="text" name="username" placeholder="Username" required/><br>
	
	<img src="p.PNG" width="60" height="40" align="left">	
    <h3 style="color:grey;">Password:</h3>
    <input type="password" name="password" placeholder="Password" required/>
	
    <br>
    <input type="submit" name="send" value="Login" class="login-button ">
    <br>
    <h6 class="no-access">Can't access your account?</h6>
	
	</form>
  </div>
</div>
      </div>

  </body>
</html>